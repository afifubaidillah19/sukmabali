<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    protected $table = 'transaction';
    protected $primaryKey = 'transaction_id';
    protected $fillable = [
        'user_id',
        'merchant_id',
        'transaction_status',
        'bupda_id',
        'message',
        'delivery_address',
        'delivery_latitude',
        'delivery_longitude',
        'delivery_fee',
        'total_price',
        'total_payment'
    ];
}
