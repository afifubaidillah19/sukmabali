<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DesaAdat extends Model
{
    protected $table = 'desa_adat';
    protected $fillable = [
        'nama',
        'alamat',
        'no_telp',
        'status'
    ];
}
