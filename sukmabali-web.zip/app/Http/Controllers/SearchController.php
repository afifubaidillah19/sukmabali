<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\ProductCategory;
use App\Bupda;
use App\Review;
use App\SearchHistory;
use App\Produsen;
use App\Helpers\GlobalHelper;
class SearchController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function generalSearch(Request $request){
        $latitude = $request->latitude;
        $longitude = $request->longitude;

        $keyword = $request->keyword;
        $response['product_list'] = Product::where('name','like','%'.$keyword.'%')
                                    ->orWhere('description','like','%'.$keyword.'%')
                                    ->get();

        for($i=0; $i<sizeOf($response['product_list']); $i++){
            $produsen = Produsen::where('id', $response['product_list'][$i]['produsen_id'])->first();
            $response['product_list'][$i]['bupda'] = Bupda::where('id',$produsen['bupda_id'])->first();
            $response['product_list'][$i]['produsen'] = $produsen;
        }
        
        $response['product_category_list'] = ProductCategory::where('name','like','%'.$keyword.'%')
                                            ->orWhere('description','like','%'.$keyword.'%')
                                            ->get();

        $bupda = Bupda::where('bupda_name','like','%'.$keyword.'%')
                            ->orWhere('description','like','%'.$keyword.'%')
                            ->get();

        $bupdaTemp = [];

        for($i=0; $i<sizeOf($bupda); $i++){
            $rating = Review::join('transaction_item','transaction_item.transaction_item_id','review.transaction_item_id')
                      ->join('transaction','transaction.transaction_id','transaction_item.transaction_id')
                      ->where('bupda_id',$bupda[$i]['id'])
                      ->get();
            
            $countRating = sizeOf($rating);
            $sumRating = $rating->sum('rating');
            $resultRating = $countRating == 0 ? 0 : $sumRating / $countRating;
            $resultRating = floatval(number_format((float)($resultRating), 1, '.', ''));
            if($resultRating == 0) $resultRating = 0;
            $bupda[$i]['rating'] = $resultRating;
            if($latitude == null || $longitude == null){
                $bupda[$i]['distance'] = 0.0;
            }else {
                $bupda[$i]['distance'] = floatval(number_format((float)GlobalHelper::haversineGreatCircleDistance($latitude, $longitude,
                    doubleval($bupda[$i]->latitude), doubleval($bupda[$i]->longitude)), 2, '.', ''));
            }
            array_push($bupdaTemp, $bupda[$i]);
        }
        usort($bupdaTemp, function($a, $b) {
            if(  $a->distance ==  $b->distance ){ return 0 ; } 
            return ($a->distance < $b->distance) ? -1 : 1;
        });

        $response['bupda_list'] = $bupdaTemp;
                                            
        $data['user_id'] = $request->user_id;
        $data['keyword'] = $keyword;
        $data['keyword_category'] = 'general';
        $data['latitude'] = $request->latitude;
        $data['longitude'] = $request->longitude;
        SearchHistory::insert($data);
        return response()->json($response);
    }

    public function merchantSearch(Request $request){
        $latitude = $request->latitude;
        $longitude = $request->longitude;
        $keyword = $request->keyword;
        $bupda = Bupda::where('bupda_name','like','%'.$keyword.'%')
                            ->orWhere('description','like','%'.$keyword.'%')
                            ->get();

        $bupdaTemp = [];

        for($i=0; $i<sizeOf($bupda); $i++){
            $rating = Review::join('transaction_item','transaction_item.transaction_item_id','review.transaction_item_id')
                      ->join('transaction','transaction.transaction_id','transaction_item.transaction_id')
                      ->where('bupda_id',$bupda[$i]['id'])
                      ->get();
            
            $countRating = sizeOf($rating);
            $sumRating = $rating->sum('rating');
            $resultRating = $countRating == 0 ? 0 : $sumRating / $countRating;
            $resultRating = floatval(number_format((float)($resultRating), 1, '.', ''));
            if($resultRating == 0) $resultRating = 0;
            $bupda[$i]['rating'] = $resultRating;
            if($latitude == null || $longitude == null){
                $bupda[$i]['distance'] = 0.0;
            }else {
                $bupda[$i]['distance'] = floatval(number_format((float)GlobalHelper::haversineGreatCircleDistance($latitude, $longitude,
                    doubleval($bupda[$i]->latitude), doubleval($bupda[$i]->longitude)), 2, '.', ''));
            }
            array_push($bupdaTemp, $bupda[$i]);
        }
        usort($bupdaTemp, function($a, $b) {
            if(  $a->distance ==  $b->distance ){ return 0 ; } 
            return ($a->distance < $b->distance) ? -1 : 1;
        });

        $data['user_id'] = $request->user_id;
        $data['keyword'] = $keyword;
        $data['keyword_category'] = 'general';
        $data['latitude'] = $request->latitude;
        $data['longitude'] = $request->longitude;
        SearchHistory::insert($data);
        return response()->json($bupdaTemp);
    }
}
