<?php

namespace App\Http\Controllers;

use App\Helpers\GlobalHelper;
use App\Transaction;
use App\Cart;
use App\TransactionItem;
use Illuminate\Http\Request;
use App\Produsen;
use App\Product;
use App\User;
use App\Bupda;
use GH;

class TransactionController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    public function addTransaction(Request $request){
        $data['user_id'] = $request->user_id;
        $data['delivery_address'] = $request->delivery_address;
        $data['delivery_latitude'] = $request->delivery_latitude;
        $data['delivery_longitude'] = $request->delivery_longitude;
        $data['transaction_status'] = GH::$TRANSACTION_STATUS_ON_PROCCESS;

        $deliveryData = json_decode($request->delivery_data);
        foreach($deliveryData as $item){
            Cart::where('cart_id',$item->cart_id)->update([
                'delivery_fee' => $item->delivery_fee
            ]);
        }

        $transactionData = Cart::join('product','product.id','cart.product_id')
                    ->join('produsen','produsen.id','product.produsen_id')
                    ->where('cart.user_id', $request->user_id)
                    ->where('cart.cart_status',GH::$CART_STATUS_ON_CART)
                    ->groupBy('bupda_id')
                    ->get();
        
        for($i=0; $i<sizeOf($transactionData); $i++){
            $data['bupda_id'] = $transactionData[$i]->bupda_id;
            $data['delivery_fee'] = json_decode($request->all()[$data['bupda_id']])->delivery_fee;
            $data['total_price'] = json_decode($request->all()[$data['bupda_id']])->total_price;
            $data['total_payment'] = json_decode($request->all()[$data['bupda_id']])->total_payment;
            $resultTransaction = Transaction::create($data);
            $dataItem['transaction_id'] = $resultTransaction->transaction_id;
            $cartData = Cart::join('product','product.id','cart.product_id')
                        ->join('produsen','produsen.id','product.produsen_id')
                        ->where('produsen.bupda_id',$data['bupda_id'])
                        ->where('cart_status',GH::$CART_STATUS_ON_CART)
                        ->get();

            for($c=0; $c<sizeOf($cartData); $c++){
                $dataItem['product_id'] = $cartData[$c]->product_id;
                $dataItem['user_id'] = $cartData[$c]->user_id;
                $dataItem['quantity'] = $cartData[$c]->quantity;
                $dataItem['price'] = $cartData[$c]->price;
                $dataItem['message'] = $cartData[$c]->message;
                $dataItem['delivery_fee'] = $cartData[$c]->delivery_fee;
                $dataItem['transaction_status'] = GH::$TRANSACTION_ITEM_STATUS_ON_PROCCESS;                
                $updateCart['cart_status'] = GH::$CART_STATUS_MOVED;
                Cart::where('cart_id', $cartData[$c]->cart_id)->update($updateCart);
                TransactionItem::create($dataItem);
                $product = Product::find($dataItem['product_id']);
                $product->stok = $product->stok - $dataItem['quantity'];
                $product->save();
            }
        }       

        $response['response_status'] = 1;
        $response['response_message'] = "Success";
        return responnse()->json($response); 
    }

    public function getTransaction(Request $request){
        $response = Transaction::where('user_id', $request->id)
            ->get();
        
        for($t=0; $t<sizeOf($response); $t++){
            $response[$t]['bupda'] = Bupda::where('id',$response[$t]['bupda_id'])->first();
            $response[$t]['bupda']['produsen_list'] 
                    = TransactionItem::select('produsen.*')
                                    ->join('product','product.id','transaction_item.product_id')
                                    ->join('produsen','produsen.id','product.produsen_id')
                                    ->where('transaction_id', $response[$t]['transaction_id'])
                                    ->groupBy('produsen.id')
                                    ->get();

            for($p=0; $p<sizeOf($response[$t]['bupda']['produsen_list']); $p++){
                $transactionItem = Transactionitem::select('transaction_item.*')
                                ->join('product','product.id','transaction_item.product_id')
                                ->join('produsen','produsen.id','product.produsen_id')
                                ->where('produsen.id', $response[$t]['bupda']['produsen_list'][$p]['id'])
                                ->where('transaction_id',$response[$t]['transaction_id'])
                                ->get();
                for($ti=0; $ti<sizeOf($transactionItem); $ti++){
                    $product = Product::where('id',$transactionItem[$ti]['product_id'])->first();
                    $transactionItem[$ti]['product'] = $product;
                }

                $response[$t]['bupda']['produsen_list'][$p]['transaction_item'] = $transactionItem;
            }
        }

        return response()->json($response);
    }
    public function getTransactionByStatusAndProdusenId(Request $request){
        $id = $request->id;
        $status = $request->status;

        $transaction = TransactionItem::join('transaction','transaction.transaction_id','transaction_item.transaction_id')
                                    ->join('product','product.id','transaction_item.product_id')
                                    ->join('produsen','produsen.id','product.produsen_id')
                                    ->where([
                                        ['produsen.id',$id],
                                        ['transaction_item.transaction_status',$status],
                                        ['transaction.transaction_status','>',0]
                                    ])
                                    ->select('transaction.*')
                                    ->groupBy('transaction.transaction_id')
                                    ->get();

        for($t=0; $t<sizeOf($transaction); $t++){
            $transactionItem = TransactionItem::where('transaction_id', $transaction[$t]['transaction_id'])
                                            ->get();
            $user = User::where('id', $transaction[$t]->user_id)->first();
            for($ti=0; $ti<sizeOf($transactionItem); $ti++){
                $product = Product::where('id', $transactionItem[$ti]['product_id'])->first();
                $transactionItem[$ti]['product'] = $product;
            }
            
            $transaction[$t]['transaction_item_list'] = $transactionItem;
            $transaction[$t]['user'] = $user;
        }
        
        return response()->json($transaction);
    }
    public function updateTransactionStatus(Request $request){
        $transaction_id = $request->transaction_id;
        $data['transaction_status'] = $request->transaction_status;

        Transaction::where('transaction_id',$transaction_id)->update($data);

        $response['response_status'] = 1;
        $response['response_message'] = "success";

        return response()->json($response);
    }

    public function updateTransactionItemStatus(Request $request){
        $produsenId = $request->produsen_id;
        $transactionId = $request->transaction_id;
        $status = $request->status;

        $resp = TransactionItem::join('product','product.id','transaction_item.product_id')
                                ->join('produsen','produsen.id','product.produsen_id')
                                ->where([
                                    ['produsen.id',$produsenId],
                                    ['transaction_id', $transactionId]
                                ])->get();
            
        $count = 0;
        foreach($resp as $item){
            $result = TransactionItem::where('transaction_item_id', $item->transaction_item_id)
                        ->update(['transaction_status' => $status]);
            if($result) $count++;
        }
        if($count = sizeOf($resp)){
            $resp = TransactionItem::where('transaction_id',$transactionId)->get();
            $countDone = 0;
            foreach($resp as $item){
                if($item->transaction_status == GH::$TRANSACTION_ITEM_STATUS_DONE){
                    $countDone++;
                }
            }

            $isSuccess = true;
            if($countDone == sizeOf($resp)){
                $resp = Transaction::where('transaction_id', $transactionId)
                            ->update(['transaction_status' => GH::$TRANSACTION_STATUS_DONE]);

                if(!$resp) $isSuccess = false;
            }

            if($isSuccess){
                return response()->json(1);
            }else {
                return response()->json(0);
            }
        }else {
            return response()->json(0);
        }
    }
}
