<?php

namespace App\Http\Controllers;

use GH;
use App\Bupda;
use Illuminate\Http\Request;
use App\Review;
use App\AdminUser;
use App\Http\Controllers\Redirect;
use App\DesaAdat;
use Hash;

class DesaAdatController extends Controller
{
    public function getDesaAdat(){
        $desaAdat = DesaAdat::whereNotIn('id',function($query){
            $query->select('desa_adat_id')
            ->from('bupda');
        })
        ->get();

        return response()->json($desaAdat);
    }

    public function tambahDesaAdat(Request $request){
        $data['nama'] = $request->nama;
        $data['alamat'] = $request->alamat;
        $data['no_telp'] = $request->no_telp;

        $desaAdat = DesaAdat::create($data);
        return response()->json($desaAdat);
    }
}
