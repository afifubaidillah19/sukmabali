<?php

namespace App\Http\Controllers;

use App\Helpers\GlobalHelper;
use App\Cart;
use Illuminate\Http\Request;

class ApiDocumentationController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }
    public function index(){
        
    }
}
