<?php

namespace App\Http\Controllers;

use App\Helpers\GlobalHelper;
use App\User;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    public function updateProfile(Request $request){
        $user_id = $request->user_id;
        $data['email'] = $request->email;
        $data['name'] = $request->full_name;
        User::where('id',$user_id)->update($data);
        $response['response_status'] = 1;
        $response['response_message'] = "success";

        return response()->json($response);
    }
}
