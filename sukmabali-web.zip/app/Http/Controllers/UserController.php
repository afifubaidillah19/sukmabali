<?php

namespace App\Http\Controllers;

use App\Helpers\GlobalHelper;
use App\User;
use Illuminate\Http\Request;
use App\Produsen;
use App\TempDesaAdat;
use App\DesaAdat;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    public function test(Request $request){
        return "hello";
    }

    public function addUser(Request $request){
        $data['firebase_user_id'] = $request->firebase_user_id;
        $data['name'] = $request->name;
        $data['email'] = $request->email;
        $data['phone_number'] = $request->phone_number;
        $data['desa_adat_id'] = $request->desa_adat_id;

        $temp_desa_adat = $request->temp_desa_adat;

        $user = User::create($data);
        if($user->desa_adat_id == 0){
            $desa['nama'] = $temp_desa_adat;
            $desa['user_id'] = $user->id;
            $desa['type_user'] = 0;
            TempDesaAdat::insert($desa);
        }else {
            $desaAdat = DesaAdat::find($user->desa_adat_id);
            $data['desa_adat'] = $desaAdat;
        }
        
        return response()->json($user);
    }

    public function cekUser(Request $request){
        $phone_number = $request->phone_number;
        $response = User::where('phone_number',$phone_number)->first();
        if($response['desa_adat_id'] != 0){
            $desaAdat = DesaAdat::find($response['desa_adat_id']);
            $response['desa_adat'] = $desaAdat;
        }
        return response()->json($response);
    }

    public function getUserDetail($id){
        $response = User::where('id',$id)->first();
        if($response['desa_adat_id'] != 0){
            $desaAdat = DesaAdat::find($response['desa_adat_id']);
            $response['desa_adat'] = $desaAdat;
        }
        $response['produsen'] = Produsen::where([
            ['user_id', $response['id']]
        ])->first();
        return response()->json($response);
    }

    public function updateDeliveryFee(Request $request){
        $id = $request->id;
        $deliveryFee = $request->delivery_fee;

        $produsen = Produsen::where('user_id',$id)->update([
            'delivery_fee_per_km' => $deliveryFee
        ]);
        
        if($produsen){
            return response()->json(1);
        }else {
            return response()->json(0);
        }
    }
}
