<?php

namespace App\Http\Controllers;

use App\Helpers\GlobalHelper;
use App\Product;
use App\ProductCategory;
use App\Bupda;
use Illuminate\Http\Request;
use GH;

class ProductController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }
    public function addProduct(Request $request){
        $response = null;
        $data = $request->all();

        if($data['id'] != ""){
            if($data['file'] != ""){
                Product::where('id', $data['id'])->update([
                    'photo_url' => GH::uploadFile($data['file'], 'product'),
                    'product_category_id' => $data['product_category_id'],
                    'name' => $data['name'],
                    'description' => $data['description'],
                    'stok' => $data['stok'],
                    'price' => $data['price']
                ]);
            }else {
                Product::where('id', $data['id'])->update([
                    'product_category_id' => $data['product_category_id'],
                    'name' => $data['name'],
                    'description' => $data['description'],
                    'stok' => $data['stok'],
                    'price' => $data['price']
                ]);
            }
            $response['response_status'] = 1;
            $response['response_message'] = 'Success';
            return response()->json($response); 
        }else {
            $data['photo_url'] = GH::uploadFile($data['file'], 'product');
            $data['product_status'] = GH::$PRODUCT_STATUS_PENDING;
            $response = Product::create($data);
            $response = Product::where('id',$response->id)->first();
        }
        

        if($response){
            $response['response_status'] = 1;
            $response['response_message'] = 'Success';
            return response()->json($response);                
        }else {
            $response['response_status'] = 0;
            $response['response_message'] = 'Failed add product data';
            return response()->json($response);       
        }
    }

    public function getProductCategory(){
        $response['data'] = ProductCategory::all();
        return response()->json($response);                
    }

    public function getProductList(){
        $product = Product::where('product_status',GH::$PRODUCT_STATUS_ENABLED)->get();
        for($i=0; $i<sizeOf($product); $i++){
            $bupda = Bupda::join('produsen','produsen.bupda_id','bupda.id')
                            ->where('produsen.id', $product[$i]->produsen_id)
                            ->select('bupda.*')
                            ->first();
            $product[$i]['bupda'] = $bupda;
        }
        return response()->json($product);
    }

    public function getProductListByBupda($bupda_id){
        $product = Bupda::join('produsen','produsen.bupda_id','bupda.id')
                        ->join('product','product.produsen_id','produsen.id')
                        ->where('bupda.id',$bupda_id)
                        ->where('product_status',GH::$PRODUCT_STATUS_ENABLED)
                        ->select('product.*')
                        ->get();
        for($i=0; $i<sizeOf($product); $i++){
            $bupda = Bupda::join('produsen','produsen.bupda_id','bupda.id')
                            ->where('produsen.id', $product[$i]->produsen_id)
                            ->select('bupda.*')
                            ->first();
            $product[$i]['bupda'] = $bupda;
        }
        return response()->json($product);
    }

    public function getProductListByProdusen($produsen_id){
        $product = Product::where('produsen_id',$produsen_id)->get();

        return response()->json($product);
    }
    
    public function getProductListByCategory($product_category_id){
        $product['data'] = Product::where('product_category_id',$product_category_id)
                                ->where('product_status', GH::$PRODUCT_STATUS_ENABLED)->get();
        for($i=0; $i<sizeOf($product['data']); $i++){
            $bupda = Bupda::join('produsen','produsen.bupda_id','bupda.id')
                            ->where('produsen.id', $product['data'][$i]->produsen_id)
                            ->select('bupda.*')
                            ->first();
            $product['data'][$i]['bupda'] = $bupda;
        }
        
        return response()->json($product);
    }
}
