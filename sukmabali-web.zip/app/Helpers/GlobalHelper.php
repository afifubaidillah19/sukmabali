<?php
namespace App\Helpers;
use App\Notification;

class GlobalHelper {
    //User Level
    public static $LEVEL_SUPER_ADMIN = 0;
    public static $LEVEL_PEMRPOV = 1;
    public static $LEVEL_BUPDA = 2;
    public static $LEVEL_USER = 3;

    //Bupda
    public static $BUPDA_ON_PENDING = 0;
    public static $BUPDA_ON_REJECTED = 1;
    public static $BUPDA_ON_ENABLED = 2;
    public static $BUPDA_ON_DISABLED = 3;
    
    //Produsen status
    public static $PRODUSEN_STATUS_PENDING = 0;
    public static $PRODUSEN_STATUS_REJECTED = 1;
    public static $PRODUSEN_STATUS_ENABLED = 2;
    public static $PRODUSEN_STATUS_DISABLED = 3;

    //Product status
    public static $PRODUCT_STATUS_PENDING = 0;
    public static $PRODUCT_STATUS_REJECTED = 1;
    public static $PRODUCT_STATUS_ENABLED = 2;
    public static $PRODUCT_STATUS_DISABLED = 3;
    public static $PRODUCT_STATUS_DELETED = 4;

    //Cart status
    public static $CART_STATUS_ON_CART = 0;
    public static $CART_STATUS_MOVED = 1;
    public static $CART_STATUS_DELETED = 2;

    //Transaction status
    public static $TRANSACTION_STATUS_ON_PROCCESS = 0;
    public static $TRANSACTION_STATUS_ACCEPTED_BY_BUPDA = 1;
    public static $TRANSACTION_STATUS_DONE = 2;
    public static $TRANSACTION_STATUS_CANCELED = 3;

    //Transaction item status
    public static $TRANSACTION_ITEM_STATUS_ON_PROCCESS = 0;
    public static $TRANSACTION_ITEM_STATUS_ON_PACKING = 1;
    public static $TRANSACTION_ITEM_STATUS_ON_DELIVERY = 2;
    public static $TRANSACTION_ITEM_STATUS_DONE = 3;


    //Notification
    public static $NOTIFICATION_TYPE_USER = 0;
    public static $NOTIFICATION_TYPE_PRODUSEN = 1;
    public static $NOTIFICATION_TYPE_BUPDA = 2;
    public static $NOTIFICATION_STATUS_UNREAD = 0;
    public static $NOTIFICATION_STATUS_READED = 1;
    
    public static function uploadFile($file, $folder){
        $fileName = time().'_'.$file->getClientOriginalName();
        $path = public_path('/uploads/images');
        $file->move($path, $fileName);

        return 'images/'.$fileName;
    }
    public static function haversineGreatCircleDistance(
        $latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371000)
    {
        // convert from degrees to radians
        $latFrom = deg2rad($latitudeFrom);
        $lonFrom = deg2rad($longitudeFrom);
        $latTo = deg2rad($latitudeTo);
        $lonTo = deg2rad($longitudeTo);
        
        $latDelta = $latTo - $latFrom;
        $lonDelta = $lonTo - $lonFrom;
        
        $angle = 2 * asin(sqrt(pow(sin($latDelta / 2), 2) +
            cos($latFrom) * cos($latTo) * pow(sin($lonDelta / 2), 2)));
        return ($angle * $earthRadius)/1000;
    }

    public static function pushNotification(
        $notification_type,
        $sender_id,
        $received_id,
        $message,
        $notification_status
    ){
        Notification::create([
            'notification_type' => $notification_type,
            'sender_id' => $sender_id,
            'received_id' => $received_id,
            'message' => $message,
            'notification_status' => $notification_status
        ]);
    }

}