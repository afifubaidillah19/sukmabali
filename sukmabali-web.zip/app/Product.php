<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = "product";
    protected $fillable = [
        'produsen_id',
        'product_category_id',
        'name',
        'description',
        'photo_url',
        'stok',
        'price',
        'product_status'
    ];
}
