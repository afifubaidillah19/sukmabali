<?php

use Illuminate\Routing\Router;

Admin::routes();

Route::group([
    'prefix'        => config('admin.route.prefix'),
    'namespace'     => config('admin.route.namespace'),
    'middleware'    => config('admin.route.middleware'),
], function (Router $router) {

    $router->get('/', 'HomeController@index')->name('admin.home');
    $router->resources([
        'produsen'         => ProdusenController::class,
        'product'          => ProductController::class,
        'bupda'            => BupdaController::class,
        'transaction'      => TransactionController::class,
        'desa_adat'        => DesaAdatController::class,
        'user'             => UserController::class,
        'temp_desa_adat'   => TempDesaAdatController::class,
        'slider'           => SliderController::class
    ]);
});
