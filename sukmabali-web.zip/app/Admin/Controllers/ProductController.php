<?php

namespace App\Admin\Controllers;

use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;
use App\Product;
use GH;
class ProductController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'Produsen';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Product);

        $grid->column('id', __('ID'))->sortable();
        $grid->column('name',__('Nama Produk'));
        $grid->column('stok');
        $grid->column('price',__('Harga'));
        $grid->column('product_status','Status Produk')->display(function(){
            switch($this->product_status){
                case GH::$PRODUCT_STATUS_PENDING:
                    return "Pending";
                break;
                case GH::$PRODUCT_STATUS_REJECTED:
                    return "Ditolak";
                break;
                case GH::$PRODUCT_STATUS_ENABLED:
                    return "Aktif";
                break;
                case GH::$PRODUCT_STATUS_DISABLED:
                    return "Dinonaktifkan";
                case GH::$PRODUCT_STATUS_DELETED:
                    return "Dihapus";
                break;

            }
        });
        $grid->column('created_at', __('Created at'));
        $grid->column('updated_at', __('Updated at'));

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed   $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Product::findOrFail($id));

        $show->field('id', __('ID'));
        $show->field('name',__('Nama Produk'));
        $show->field('stok');
        $show->field('price',__('Harga'));
        $show->field('product_status','Status Produk')->as(function(){
            switch($this->product_status){
                case GH::$PRODUCT_STATUS_PENDING:
                    return "Pending";
                break;
                case GH::$PRODUCT_STATUS_REJECTED:
                    return "Ditolak";
                break;
                case GH::$PRODUCT_STATUS_ENABLED:
                    return "Aktif";
                break;
                case GH::$PRODUCT_STATUS_DISABLED:
                    return "Dinonaktifkan";
                case GH::$PRODUCT_STATUS_DELETED:
                    return "Dihapus";
                break;

            }
        });
        $show->field('photo_url',__('Foto'))->image();
        $show->field('created_at', __('Created at'));
        $show->field('updated_at', __('Updated at'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Product);

        $form->display('id', __('ID'));
        $form->text('name',__('Nama Produk'));
        $form->text('stok');
        $form->text('price',__('Harga'));
        $form->image('photo_url',__('Foto'));
        $form->select('product_status','Status Product')->options([
            GH::$PRODUCT_STATUS_PENDING => 'Pending',
            GH::$PRODUCT_STATUS_REJECTED => 'Ditolak',
            GH::$PRODUCT_STATUS_ENABLED => 'Setujui / Aktifkan',
            GH::$PRODUCT_STATUS_DISABLED => 'Nonaktifkan',
            GH::$PRODUCT_STATUS_DELETED => 'Hapus'
        ]);
        $form->display('created_at', __('Created At'));
        $form->display('updated_at', __('Updated At'));

        return $form;
    }
}
