<?php

namespace App\Admin\Controllers;

use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;
use App\Transaction;
use GH;
use App\User;
class TransactionController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'Example controller';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Transaction);

        $grid->column('transaction_id', __('ID'))->sortable();
        $grid->column('transaction_status')->display(function(){
            switch($this->transaction_status){
                case GH::$TRANSACTION_STATUS_ON_PROCCESS:
                    return "Sedang Diproses";
                break;
                case GH::$TRANSACTION_STATUS_ACCEPTED_BY_BUPDA:
                    return "Diterima Oleh Bupda";
                break;
                case GH::$TRANSACTION_STATUS_DONE:
                    return "Selesai";
                break;
                case GH::$TRANSACTION_STATUS_CANCELED:
                    return "Dibatalkan";
                break;

            }
        });
        $grid->column('user_id',__('Pemesan'))->display(function($user_id){
            return User::find($user_id)->name;
        });
        $grid->column('created_at', __('Created at'));
        $grid->column('updated_at', __('Updated at'));

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed   $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Transaction::findOrFail($id));

        $show->field('transaction_id', __('ID'));
        $show->field('transaction_status')->as(function(){
            switch($this->transaction_status){
                case GH::$TRANSACTION_STATUS_ON_PROCCESS:
                    return "Sedang Diproses";
                break;
                case GH::$TRANSACTION_STATUS_ACCEPTED_BY_BUPDA:
                    return "Diterima Oleh Bupda";
                break;
                case GH::$TRANSACTION_STATUS_DONE:
                    return "Selesai";
                break;
                case GH::$TRANSACTION_STATUS_CANCELED:
                    return "Dibatalkan";
                break;

            }
        });
        $show->field('created_at', __('Created at'));
        $show->field('updated_at', __('Updated at'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Transaction);

        $form->display('transaction_id', __('ID'));
        $form->display('created_at', __('Created At'));
        $form->display('updated_at', __('Updated At'));
        $form->select('transaction_status')->options([
            GH::$TRANSACTION_STATUS_ON_PROCCESS => 'Sedang Diproses',
            GH::$TRANSACTION_STATUS_ACCEPTED_BY_BUPDA => 'Diterima Oleh Bupda',
            GH::$TRANSACTION_STATUS_DONE => 'Selesai',
            GH::$TRANSACTION_STATUS_CANCELED => 'Dibatalkan'
        ]);
        return $form;
    }
}
