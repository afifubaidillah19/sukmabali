<?php

namespace App\Admin\Controllers;

use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;
use App\Produsen;
use GH;

class ProdusenController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'Produsen';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Produsen);

        $grid->column('id', __('ID'))->sortable();
        $grid->column('produsen_name',__('Nama Produsen'));
        $grid->column('phone_number',__('Nomor Telepon'));
        $grid->column('email',__('Email'));
        $grid->column('produsen_status',__('Status Produsen'))->display(function(){
            switch($this->produsen_status){
                case GH::$PRODUSEN_STATUS_PENDING:
                    return "Pending";
                break;
                case GH::$PRODUSEN_STATUS_REJECTED:
                    return "Ditolak";
                break;
                case GH::$PRODUSEN_STATUS_ENABLED:
                    return "Aktif";
                break;
                case GH::$PRODUSEN_STATUS_DISABLED:
                    return "Dinonaktifkan";
                break;
            }
        });
        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed   $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Produsen::findOrFail($id));

        $show->field('id', __('ID'));
        $show->field('email',__('Email'));
        $show->field('phone_number',__('Nomor Telepon'));
        $show->field('address',__('Alamat'));
        $show->field('latitude');
        $show->field('longitude');
        $show->field('description',__('Deskripsi'));
        $show->field('verification_photo_path',__('Foto Identitas'))->image();
        $show->field('produsen_status',__('Status Produsen'))->as(function(){
            switch($this->produsen_status){
                case GH::$PRODUSEN_STATUS_PENDING:
                    return "Pending";
                break;
                case GH::$PRODUSEN_STATUS_REJECTED:
                    return "Ditolak";
                break;
                case GH::$PRODUSEN_STATUS_ENABLED:
                    return "Aktif";
                break;
                case GH::$PRODUSEN_STATUS_DISABLED:
                    return "Dinonaktifkan";
                break;
            }
        });
        $show->field('created_at', __('Created at'));
        $show->field('updated_at', __('Updated at'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Produsen);

        $form->display('id', __('ID'));
        $form->text('produsen_name',__('Nama Produsen'));
        $form->text('email',__('Email'));
        $form->text('phone_number',__('Nomor Telepon'));
        $form->text('address',__('Alamat'));
        $form->text('latitude');
        $form->text('longitude');
        $form->text('description',__('Deskripsi'));
        $form->image('verification_photo_path',__('Foto Identitas'));
        $form->text('produsen_status',__('Status Produsen'));
        $form->select('produsen_status')->options([
            GH::$PRODUSEN_STATUS_PENDING => 'Pending',
            GH::$PRODUSEN_STATUS_REJECTED => 'Ditolak',
            GH::$PRODUSEN_STATUS_ENABLED => 'Setujui / Aktifkan',
            GH::$PRODUSEN_STATUS_DISABLED => 'Nonaktifkan'
        ]);
        $form->display('created_at', __('Created At'));
        $form->display('updated_at', __('Updated At'));

        return $form;
    }
}
