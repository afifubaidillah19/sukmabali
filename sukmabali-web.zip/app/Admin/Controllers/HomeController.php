<?php

namespace App\Admin\Controllers;

use App\Http\Controllers\Controller;
use Encore\Admin\Controllers\Dashboard;
use Encore\Admin\Layout\Column;
use Encore\Admin\Layout\Content;
use Encore\Admin\Layout\Row;
use Encore\Admin\Widgets\InfoBox;
use App\Produsen;
use App\Product;
use App\Bupda;
use Admin;

class HomeController extends Controller
{
    public function index(Content $content)
    {
        if(Admin::user()->isRole('administrator')){
            return $content
            ->header('Dashboard')
            ->description('Description...')
            ->row(function(Row $row) {
                $row->column(3, new InfoBox('Produsen', 'users', 'green', '/admin/users', Produsen::count()));
                $row->column(3, new InfoBox('Produk', 'cube', 'orange', '/admin/users', Product::count()));
            });
        }else if(Admin::user()->isRole('bupda')){
            return $content
            ->header('Dashboard')
            ->description('Description...')
            ->row(function(Row $row) {
                $row->column(3, new InfoBox('Produsen', 'users', 'green', '/admin/users', Produsen::count()));
                $row->column(3, new InfoBox('Produk', 'cube', 'orange', '/admin/users', Product::count()));
            });
        }else if(Admin::user()->isRole('pemprov')){
            return $content
            ->header('Dashboard')
            ->description('Description...')
            ->row(function(Row $row) {
                $row->column(3, new InfoBox('Bupda', 'users', 'blue', '/admin/users', Bupda::count()));
                $row->column(3, new InfoBox('Produsen', 'users', 'green', '/admin/users', Produsen::count()));
                $row->column(3, new InfoBox('Produk', 'cube', 'orange', '/admin/users', Product::count()));
            });
        }
    }
}
