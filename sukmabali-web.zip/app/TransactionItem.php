<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransactionItem extends Model
{
    protected $table = 'transaction_item';
    protected $primaryKey = 'transaction_item_id';
    protected $fillable = [
        'transaction_id',
        'product_id',
        'price',
        'quantity',
        'message',
        'transaction_status',
        'delivery_fee'
    ];
}
