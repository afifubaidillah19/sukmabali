<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="{{asset('css/font.css')}}">
  <link rel="stylesheet" type="text/css" href="{{asset('css/style.css')}}">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container-fluid">
		<div class="container">
			<nav class="navbar navbar-expand-md">
			  <!-- Brand -->
			  <a class="navbar-brand" href="#"><img src="image/logo3.png"></a>

			  <!-- Toggler/collapsibe Button -->
			  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
			    <span class="navbar-toggler-icon" style="color: black"><img src="image/burger.png" style="height: 20px;"></span>
			  </button>

			  <!-- Navbar links -->
			  <div class="collapse navbar-collapse" id="collapsibleNavbar">
			    <ul class="navbar-nav">
			      <li class="nav-item">
			        <a class="nav-link" href="#">Home</a>
			      </li>
			      <li class="nav-item">
			        <a class="nav-link" href="#">Fitur</a>
			      </li>
			      <li class="nav-item">
			        <a class="nav-link" href="#">Kontak</a>
				  </li>
				  <li class="nav-item">
			        <a class="nav-link" href="{{URL('admin/auth/login')}}">Masuk</a>
			      </li>
				  <li class="nav-item">
			        <a class="nav-link" href="{{URL('register')}}">Daftar</a>
			      </li>
			      <li class="nav-item">
			        <a class="nav-link" href="#">Download</a>
			      </li>
			    </ul>
			  </div>
			</nav>

			<div class="row banner d-flex align-items-center">
				<div class="col-md-6">
					<h2>Jangkau potensi pasar yang lebih besar</h2>
					<p>SukmaBali adalah sebuah sistem berbasis e-marketplace
 yang mampu mengelola badan-badan usaha kecil seperti
 warung, UMKM, petani, nelayan, dan lain-lain di sebuah desa adat dimana
 mereka menjalankan usaha.</p>
 <div>
 	<button>Coming Soon</button>
 </div>
				</div>
				<div class="col-md-6 d-flex">
					<img src="{{asset('image/hero_image.png')}}">
				</div>
			</div>	
			<div class="row content end-section" style="margin-top: 120px;">
				<div style="text-align: center; width: 100%; font-family: PRegular; font-size: 40px;" >
					Kenapa Produsen Memilih <strong>SukmaBali</strong>
				</div>
				<div style="background: linear-gradient(169deg, #FECC92 0%, #FECC92 0%, #FF0100 100%); height: 7px; width: 95px; position: relative;left: 50%; transform: translateX(-50%); margin-top: 20px; border-radius: 20px;">
					
				</div>
				<div style="width: 100%; margin-top: 80px; flex-wrap: wrap;" class="d-flex justify-content-between">
					<div class="col-md-3">
						<img src="{{asset('image/illustrasi_1.png')}}">
						<h2>Jangkauan Luas</h2>
						<p>Menyelesaikan masalah produsen yang memiliki keterbatasan karena jangkauan penjualannya tidak luas</p>
					</div>
					<div class="col-md-3">
						<img src="{{asset('image/illustrasi_2.png')}}">
						<h2>Ekonomi 4.0</h2>
						<p>Menunjang dan mengedepankan ekonomi kemasyarakatan 4.0 bagi warga bali</p>
					</div>
					<div class="col-md-3">
						<img src="{{asset('image/illustrasi_3.png')}}">
						<h2>Produk Unik</h2>
						<p>Konsumen yang membutuhkan produk spesifik dari suatu daerah</p>
					</div>
				</div>
			</div>	
		</div>
	</div>
</body>
</html>