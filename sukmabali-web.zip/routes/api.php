<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::get('/hello', function(){
    return "Hello World";
});

$router->group(['middleware' => 'api'], function() use ($router) {
    $router->get('/test', function () use ($router) {
        return GH::$PRODUSEN_STATUS_PENDING;
    });

    $router->post('/get_home_data','HomeController@getHomeData');
    $router->post('/get_merchant_home_data','HomeController@getMerchantHomeData');
    
    //User
    $router->post('/add_user','UserController@addUser');
    $router->post('/cek_user','UserController@cekUser');
    $router->get('/user/{id}','UserController@getUserDetail');

    //Produsen
    $router->post('/add_produsen','ProdusenController@addProdusen');
    
    //BUPDA
    $router->post('/get_bupda_list','BupdaController@getBupdaList');

    //Product
    $router->post('/add_product','ProductController@addProduct');
    $router->get('/get_product_category','ProductController@getProductCategory');
    $router->get('/get_product_list','ProductController@getProductList');
    $router->get('/get_product_list_by_bupda/{bupda_id}','ProductController@getProductListByBupda');
    $router->get('/get_product_list_by_category/{product_category_id}','ProductController@getProductListByCategory');
    $router->get('/get_product_list_by_produsen/{produsen_id}','ProductController@getProductListByProdusen');
    //Cart
    $router->post('/get_cart_data','CartController@getCartData');
    $router->post('/add_cart','CartController@addCart');
    $router->post('/update_cart_status','CartController@updateCartStatus');
    $router->post('/update_cart_quantity','CartController@updateCartQuantity');
    //Transaction
    $router->post('/add_transaction','TransactionController@addTransaction');
    $router->post('/get_transaction','TransactionController@getTransaction');
    $router->post('/update_transaction_status','TransactionController@updateTransactionStatus');
    $router->post('/get_transaction_by_status_and_produsen_id','TransactionController@getTransactionByStatusAndProdusenId');
    $router->post('/update_transaction_item_status','TransactionController@updateTransactionItemStatus');
    //Search
    $router->post('/general_search','SearchController@generalSearch');
    $router->post('/merchant_search','SearchController@merchantSearch');

    //Review
    $router->post('/give_review','ReviewController@giveReview');
    $router->post('/get_product_list_for_review','ReviewController@getProductListForReview');
    $router->get('/get_review_list_by_product_id/{product_id}','ReviewController@getReviewListByProductId');

    //Profile
    $router->post('/update_profile','ProfileController@updateProfile');
    $router->post("/update_delivery_fee","UserController@updateDeliveryFee");

    //Desa Adat
    $router->get('/get_desa_adat','DesaAdatController@getDesaAdat');
    $router->post('/tambah_desa_adat','DesaAdatController@tambahDesaAdat');
});
